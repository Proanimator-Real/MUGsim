# What Is MUG sim?
This Game Is Not A Mug Simulator,
Its A Game I'm Working On That's Physics Simulator,
Make Sure To Report Any Bugs But For The Most Part, Enjoy The Game.

# Are There Limits?
Well Yes But If You Want A Me To Code Somthing Into This Be Sure To Tell Me

# What Is This All About?
I Just Never Been Able To Make A Physics Simulator But Today Is When I Try to.